/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.form;

/**
 *
 * @author HP
 */
public class FORM {

    public static void main(String[] args) {
        FORMframe fr=new FORMframe();
        fr.show();
    }
}
